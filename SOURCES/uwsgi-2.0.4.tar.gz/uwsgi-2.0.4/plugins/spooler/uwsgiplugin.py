NAME='spooler'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['spooler_plugin']
