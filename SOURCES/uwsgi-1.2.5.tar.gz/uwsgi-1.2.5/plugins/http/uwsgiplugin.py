
NAME='http'
CFLAGS = []
LDFLAGS = []
LIBS = []

GCC_LIST = ['http']
