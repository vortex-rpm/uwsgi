
NAME='fastrouter'
CFLAGS = []
LDFLAGS = []
LIBS = []

GCC_LIST = ['fr_sctp', 'fr_map', 'fastrouter', 'fr_events']
